package com.mycompany.trabalhopoo;

public class Carrinho {
    
}
