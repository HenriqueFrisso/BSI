package com.mycompany.trabalhopoo;

import viewer.Tela;

public class Main {

    public static void main(String[] args) {
        Tela tela = new Tela();
        tela.setVisible(true);
    }
}
