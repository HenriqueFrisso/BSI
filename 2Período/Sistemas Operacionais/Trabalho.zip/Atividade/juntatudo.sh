#!/bin/bash
echo "Digite a string: "
read string;
echo "$string" | tr -d ' '

