#!/bin/bash
 linha=$(cat "/etc/passwd"|tr -s ":" " "| cut -d " " -f 1,5)
 echo "$linha"


 





