#!/bin/bash

palavra1="$1"
palavra2="$2"

if echo "$palavra2" | grep "$palavra1" > /dev/null; then
    echo "A primeira palavra está contida na segunda"
fi

