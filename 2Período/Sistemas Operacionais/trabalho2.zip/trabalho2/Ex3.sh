#!/bin/bash

if [ $# -ne 3 ]; then
  echo "Uso: $0 <operando1> <operador> <operando2>"
  exit 1
fi

numero1="$1"
sinal="$2"
numero2="$3"

case "$sinal" in
  "+")
    resultado=$(echo "$numero1 + $numero2" | bc)
    ;;
  "-")
    resultado=$(echo "$numero1 - $numero2" | bc)
    ;;
  "*")
    resultado=$(echo "$numero1 * $numero2" | bc)
    ;;
  "/")
    resultado=$(echo "$numero1 / $numero2" | bc)
    ;;
  *)
    exit 1
    ;;
esac

echo "Resultado: $resultado"

