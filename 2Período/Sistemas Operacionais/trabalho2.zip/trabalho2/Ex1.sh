#!/bin/bash
echo "1 – Exibir status da utilização das partições do sistema; (df -h)"
echo "2 – Exibir relação de usuário logados; (who)"
echo "3 – Exibir data/hora; (date)"
echo "4 – Sair."

echo "Digite a opção: "
read num;

while [ $num -lt 1 ] || [ $num -gt 4 ]; do
	echo "1 – Exibir status da utilização das partições do sistema; (df -h)"
	echo "2 – Exibir relação de usuário logados; (who)"
	echo "3 – Exibir data/hora; (date)"
	echo "4 – Sair."
	echo "Digite a opção: "
	read num;
	done
	
if [ $num -eq 1 ]; then
	df -h
	
elif [ $num -eq 2 ]; then
	who
	
elif [ $num -eq 3 ]; then
	date
	
fi

