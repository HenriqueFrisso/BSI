#!/bin/bash

echo "Usuários cadastrados no sistema e seus diretórios home:"
while IFS=: read -r user pass uid gid info home shell; do
  echo "$user => $home"
done < /etc/passwd
