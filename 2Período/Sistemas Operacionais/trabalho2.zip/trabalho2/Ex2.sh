if [ $# -lt 2 ]; then
  echo "Por favor, forneça pelo menos duas palavras para ordenar."
  exit 1
fi

sorted_words=$(echo "$@" | tr ' ' '\n' | sort)

echo "Palavras ordenadas em ordem alfabética:"
echo "$sorted_words"
