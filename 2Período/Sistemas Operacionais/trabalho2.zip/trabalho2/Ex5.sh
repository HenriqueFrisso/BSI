#!/bin/bash

echo "Shell mais utilizado:"
cut -d: -f7 /etc/passwd | sort | uniq -c | sort -n | tail -n 1
